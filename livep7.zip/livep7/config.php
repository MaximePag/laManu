<?php
//Constante pour la connexion à la base de données
define('SQL_HOST', 'localhost');
define('SQL_DBNAME', 'livep7');
define('SQL_USER', 'toto');
define('SQL_PWD', 'toto');
define('SQL_PREFIX', '`g645gd456_');
