<?php
define('REGISTER_TITLE', 'Account registration');